var express = require("express");
var mongoose = require("mongoose");
var app = express();
var database = require("./config/database");

mongoose.connect(database.url);

const connectDB = async () => {
    try {
      const conn = await mongoose.connect(database.url);
      console.log(`MongoDB Connected`);
    } catch (error) {
      console.log(error);
      process.exit(1);
    }
  }
connectDB().then(() => {
    app.listen(6000, () => {
        console.log("App listening on port : " + 6000);
    })
})