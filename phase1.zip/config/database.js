module.exports = {
    url: "mongodb+srv://george97dj:appu5864@cluster0.pw27ep7.mongodb.net/sample_mflix",
    secret: "secret"
}
